// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyBuyPeCGPMSBGeWwb2xHmsJ7WTPabLLZOQ",
  authDomain: "fir-lab-fc72e.firebaseapp.com",
  projectId: "fir-lab-fc72e",
  storageBucket: "fir-lab-fc72e.appspot.com",
  messagingSenderId: "311461490191",
  appId: "1:311461490191:web:d0a60092ec36842c76fd7a",
  measurementId: "G-FJXFE73R8B",
});

const db = getFirestore(firebaseApp);
export default db;
